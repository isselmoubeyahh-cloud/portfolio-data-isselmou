## Données (non publiées)

Les données EPCV utilisées dans ce projet ne sont pas publiées dans ce dépôt (confidentialité / droits d’accès).

Pour reproduire l’analyse :
1. placer un fichier `data.csv` dans ce dossier,
2. conserver les mêmes noms de variables que dans le notebook (si vous l’ajoutez).
